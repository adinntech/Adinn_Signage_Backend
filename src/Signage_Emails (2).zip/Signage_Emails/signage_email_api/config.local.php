<?php
// Secrets for the cPanel server. Do NOT commit. Upload next to config.php.
// SMTP uses the same local relay as the Roadshow mailer (localhost:25, no auth), so only the API key is needed.
return [
 'SIGNAGE_API_KEY'=>'52b88005161c4421d2bada4392ca655c0d368c4c5e273e13e54cfc943509d443',
];
