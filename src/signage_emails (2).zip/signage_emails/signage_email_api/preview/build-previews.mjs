// Writes static HTML previews of the signage mails with sample data, so the layout can be checked in a browser without PHP.
// Run:  node src/signage_emails/signage_email_api/preview/build-previews.mjs
// This is a JS mirror of templates/_common.php + the templates; keep the two in step when the design changes.
import { writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const out = dirname(fileURLToPath(import.meta.url));
const F = "-apple-system,'Segoe UI',Roboto,Arial,Helvetica,sans-serif";
const INK = '#1f2937', MUTED = '#6b7280', LINE = '#e5e7eb', ACCENT = '#b91c1c';
const LOGO = 'https://adinnroadshows.com/images/logo/AdinnLogo.png';
const esc = (v) => String(v ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#039;');

const start = (title, sub = '') =>
  `<!doctype html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)} (preview)</title></head>` +
  `<body style="margin:0;padding:0;background:#f3f4f6;font-family:${F};color:${INK}"><table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f3f4f6"><tr><td align="center" style="padding:24px 10px">` +
  `<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:620px;background:#ffffff;border:1px solid ${LINE};border-top:3px solid ${ACCENT}">` +
  `<tr><td style="padding:20px 28px 14px;border-bottom:1px solid ${LINE}"><table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr><td valign="middle"><img src="${LOGO}" alt="Adinn" height="30" style="height:30px;width:auto;border:0;display:block"></td><td valign="middle" align="right" style="font-size:11px;color:${MUTED};font-family:${F}">Signage Solutions<br>System generated email</td></tr></table></td></tr>` +
  `<tr><td style="padding:22px 28px 8px;font-family:${F}"><div style="font-size:19px;line-height:1.35;font-weight:600;color:#111827;margin:0 0 ${sub ? 4 : 14}px">${esc(title)}</div>${sub ? `<div style="font-size:13px;line-height:1.6;color:${MUTED};margin:0 0 14px">${esc(sub)}</div>` : ''}`;
const chips = (d, type) =>
  `<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin:0 0 20px;border-top:1px solid ${LINE};border-bottom:1px solid ${LINE}"><tr>` +
  [['Request ID', d.requestId], ['Date', d.date], ['Type', type], ['Requested by', d.source]].map(([l, v]) => `<td valign="top" style="padding:10px 8px 10px 0"><div style="font-size:11px;color:${MUTED}">${esc(l)}</div><div style="font-size:13px;color:${INK};word-break:break-word">${esc(v)}</div></td>`).join('') + '</tr></table>';
const para = (h) => `<p style="font-size:13px;line-height:1.7;color:${INK};margin:0 0 16px">${h}</p>`;
const rows = (r) => `<table role="presentation" width="100%" cellpadding="0" cellspacing="0">${r.filter(([, v]) => String(v ?? '').trim()).map(([l, v]) => `<tr><td valign="top" width="34%" style="padding:7px 10px 7px 0;border-bottom:1px solid #f0f1f3;font-size:12px;color:${MUTED}">${esc(l)}</td><td valign="top" style="padding:7px 0;border-bottom:1px solid #f0f1f3;font-size:13px;color:${INK};word-break:break-word">${esc(v)}</td></tr>`).join('')}</table>`;
const card = (t, body) => `<div style="margin:0 0 22px"><div style="font-size:12px;font-weight:600;letter-spacing:.4px;text-transform:uppercase;color:#374151;padding:0 0 6px;border-bottom:1px solid #d1d5db">${esc(t)}</div>${body}</div>`;
const files = (t, list) => card(t, `<table role="presentation" width="100%" cellpadding="0" cellspacing="0">${list.map(([n, m]) => `<tr><td style="padding:7px 0;border-bottom:1px solid #f0f1f3;font-size:13px;color:${INK}">${esc(n)}</td><td align="right" style="padding:7px 0 7px 10px;border-bottom:1px solid #f0f1f3;font-size:11px;color:${MUTED};white-space:nowrap">${esc(m)}</td></tr>`).join('')}</table>`);
const note = (t) => `<div style="margin:4px 0 22px;padding:2px 0 2px 12px;border-left:3px solid ${ACCENT};font-size:13px;line-height:1.7;color:${INK}">${esc(t)}</div>`;
const end = (g, team) =>
  `<p style="font-size:13px;line-height:1.7;color:${INK};margin:0 0 20px">${esc(g)}<br>${esc(team)}<br><span style="color:${MUTED}">Adinn Advertising Services Ltd.</span></p></td></tr>` +
  `<tr><td style="padding:12px 28px;border-top:1px solid ${LINE};font-size:11px;line-height:1.6;color:#9ca3af;font-family:${F}">This is a system generated email from the Adinn Signage CRM. Please reply to this email only as described above.</td></tr></table></td></tr></table></body></html>`;

const meta = (id, source = 'Operations Team') => ({ requestId: id, date: '13 Nov 2026', source });

// 1. Vendor registration
writeFileSync(join(out, 'vendor-registration.html'),
  start('Vendor Registration Request') + chips(meta('Adn-Signage-VenReg-13112601'), 'Vendor Registration') +
  para('Dear Accounts Team,<br>Please register the vendor below in Zoho Books.') +
  card('Vendor Details', rows([['Vendor / Firm', 'Sri Murugan Signs'], ['Vendor Type', 'Organization'], ['CRM Code', 'VND-0042'], ['Contact Person', 'Sathish, Manager'], ['Mobile', '8980898988'], ['Email', 'sathish@gmail.com'], ['Address', 'No.32, Pandiyan Street, Pikulam, Madurai, Tamil Nadu, 625010'], ['Service Area', 'Madurai, Theni']])) +
  card('Tax and Bank Details', rows([['PAN', 'ABCDE1234F'], ['GST', '33ABCDE1234F1Z5'], ['Aadhaar', 'XXXX XXXX 4821'], ['Bank (Name / Account / IFSC)', 'Sri Murugan Signs / 123456789012 / SBIN0001234']])) +
  files('KYC Documents', [['pan.pdf', 'PDF · 120 KB · PAN card'], ['cancelled-cheque.png', 'PNG · 340 KB · Cancelled cheque']]) +
  note('Reply to this email with the Vendor ID (5 digits or more), for example "Vendor ID: 12345". Keep the Request ID in the subject.') +
  end('Regards,', 'Operations Team'));

// 2. Vendor rate approval
const th = (t, a = 'right') => `<td align="${a}" style="padding:8px 8px 8px 0;font-size:11px;letter-spacing:.3px;text-transform:uppercase;color:${MUTED};border-bottom:1px solid #d1d5db">${t}</td>`;
const cell = 'padding:8px 8px 8px 0;border-bottom:1px solid #f0f1f3;font-size:13px;';
const arow = (l, lim, cur, req) => `<tr><td style="${cell}color:${MUTED}">${l}</td><td align="right" style="${cell}color:#9ca3af;text-decoration:line-through">${lim}</td><td align="right" style="${cell}color:${INK}">${cur}</td><td align="right" style="${cell}color:${ACCENT};padding-right:0">${req}</td></tr>`;
writeFileSync(join(out, 'vendor-rate-approval.html'),
  start('Vendor Rate Approval Request') + chips(meta('Adn-Signage-VenRate-13112601'), 'Rate Approval') +
  para('Dear Sir/Madam,<br>The rate entered for the vendor below is above the company rate set by Admin. Please review the figures and confirm.') +
  card('Vendor Details', rows([['Vendor', 'Adn Signage'], ['Vendor ID', '13200'], ['Mobile', '8930898988'], ['Email', 'sathish@gmail.com'], ['Address', 'Madurai'], ['Entered by', 'Sathish']])) +
  card('Rate Details', `<table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr>${th('Item', 'left')}${th('Company rate')}${th('Current')}${th('Requested')}</tr>${arow('Price per shop', '₹250', '₹240', '₹260')}${arow('Travelling cost per shop', '₹300', '-', '₹320')}</table>`) +
  note('Reply with exactly one of the following: APPROVED to accept the requested rate, or NOT APPROVED to keep the company rate. Keep the Request ID in the subject.') +
  end('Regards,', 'Operations Team'));

// 3. Project code
writeFileSync(join(out, 'project-code.html'),
  start('Project Code Creation Request') + chips(meta('Adn-Signage-ProCode-13112601', 'Client Servicing Team'), 'Project Code') +
  para('Dear Team,<br>This is a new client. Please create the client ID in Zoho, then the project code and estimation code for the order below.') +
  card('Client', rows([['Client', 'Devraj Reprographic Industries'], ['Contact Person', 'Sathish, Manager'], ['Mobile', '8980898988'], ['Email', 'sathish@adinn.com'], ['GST', '33ABCDE1234F1Z5'], ['Address', 'Adhithan Nagar, Madurai, 625006']])) +
  card('Order', rows([['Order No', 'ORD-2026-0042'], ['Project Type', 'Signage Solution'], ['Location', 'Madurai'], ['Scope', 'Shop board recce, 120 shops']])) +
  files('Project Documents', [['requirement.pdf', 'PDF · 410 KB']]) +
  note('Reply with the code as "Project Code: 12345678" (8 digits or more), and any estimate numbers as EST-123456. Keep the Request ID in the subject.') +
  end('Regards,', 'Client Servicing Team'));

// 4. Forgot password
const digits = [...'482915'].map((d) => `<td align="center" width="38" style="width:38px;height:46px;background:#ffffff;border:1px solid #d1d5db;font-family:Consolas,'Courier New',monospace;font-size:26px;color:#111827">${d}</td><td width="6" style="width:6px;font-size:0">&nbsp;</td>`).join('');
writeFileSync(join(out, 'forgot.html'),
  start('Reset Your Password') + para('Hi Ravi Kumar,<br>Use the verification code below in the Signage app to set a new password.') +
  `<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin:0 0 20px"><tr><td align="center" style="background:#f9fafb;border:1px solid ${LINE};padding:18px 10px"><div style="font-size:11px;letter-spacing:1px;text-transform:uppercase;color:${MUTED};margin-bottom:10px">Verification code</div><table role="presentation" align="center" cellpadding="0" cellspacing="0" style="margin:0 auto"><tr>${digits}</tr></table><div style="margin-top:14px"><a href="../copy.html#482915" target="_blank" style="display:inline-block;background:${ACCENT};color:#ffffff;font-size:13px;text-decoration:none;padding:9px 20px">Copy code</a></div><div style="font-size:12px;color:${MUTED};margin-top:10px">Valid for 10 minutes. Can be used once.</div></td></tr></table>` +
  card('How to reset', `<ol style="margin:8px 0 0 18px;padding:0;font-size:13px;line-height:1.9;color:${INK}"><li>Open the Signage app and tap Forgot password.</li><li>Enter your email and this code.</li><li>Choose a new password and sign in.</li></ol>`) +
  note('If you did not ask for this, ignore this email; your current password stays the same. Never share this code with anyone, including the Adinn team.') +
  end('Regards,', 'Adinn Signage Support'));

console.log('Wrote vendor-registration.html, vendor-rate-approval.html, project-code.html, forgot.html in', out);
