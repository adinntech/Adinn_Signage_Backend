<?php require_once __DIR__.'/_common.php';
$c=is_array($data['client']??null)?$data['client']:[];$p=is_array($data['project']??null)?$data['project']:[];

pageStart('Project Code Creation Request','',$config);
chips($data,'Project Code');

$hasDetails=is_array($data['details']['sections']??null)&&count($data['details']['sections'])>0;
if($hasDetails){
 $d=$data['details'];
 $line=!empty($d['existing'])
  ?'Please create the project code and estimation code for the order below under Client ID '.(($d['clientId']??'')!==''?$d['clientId']:'-').'.'
  :'This is a new client. Please create the client ID in Zoho, then the project code and estimation code for the order below.';
 para('Dear Team,<br>'.esc($line));
 detailsCards($data);
}else{
 para('Dear Team,<br>Please create a project code for the order below.');
 echo card('Project Details',rowsHtml([
  ['','Client Name',$c['clientName']??''],
  ['','Client Code',($c['clientCode']??'')!==''?$c['clientCode'].' (existing)':''],
  ['','Project Name',$p['projectName']??''],
  ['','Project Type',$p['projectType']??''],
  ['','Location',$p['location']??''],
  ['','Start Date',$p['startDate']??''],
  ['','End Date',$p['endDate']??''],
  ['','Business Unit',$p['businessUnit']??''],
  ['','Description',$p['description']??''],
  ['','Remarks',$p['remarks']??''],
 ]));
}

if($hasDetails)noteBlock($data,'Note from '.(($data['source']??'')!==''?$data['source']:'Client Servicing'));
else messageBlock($data);
attachmentsCard($data,'Project Documents');

noteBar('Reply with the code as "Project Code: 12345678" (8 digits or more), and any estimate numbers as EST-123456. Keep the Request ID in the subject.');
pageEnd('Regards,','Client Servicing Team',$config);
