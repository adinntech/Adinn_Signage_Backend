<?php require_once __DIR__.'/_common.php';
/* Vendor registration request. The CRM sends the vendor's data (vendor.*), the optional note typed on the mail screen
   (bodyHtml) and the files; the whole layout is built here. */
$v=is_array($data['vendor']??null)?$data['vendor']:[];
$bank=is_array($v['bank']??null)?$v['bank']:[];
$areas=is_array($v['serviceAreas']??null)?implode(', ',array_map('strval',$v['serviceAreas'])):'';
$gst=trim((string)($v['gstin']??''));
if($gst===''&&array_key_exists('hasGst',$v)&&$v['hasGst']===false)$gst='Not registered for GST';
$bankLine=implode(' / ',array_filter([$bank['accountName']??'',$bank['accountNo']??'',$bank['ifsc']??''],static fn($x)=>trim((string)$x)!==''));
$contact=implode(', ',array_filter([$v['contactPerson']??'',$v['designation']??''],static fn($x)=>trim((string)$x)!==''));
$place=implode(', ',array_filter([$v['address']??'',$v['district']??'',$v['state']??'',$v['pincode']??''],static fn($x)=>trim((string)$x)!==''));

pageStart('Vendor Registration Request','',$config);
chips($data,'Vendor Registration');

para('Dear Accounts Team,<br>Please register the vendor below in Zoho Books.');

echo card('Vendor Details',rowsHtml([
 ['','Vendor / Firm',$v['vendorName']??''],
 ['','Vendor Type',$v['vendorType']??''],
 ['','CRM Code',$v['vendorCode']??''],
 ['','Contact Person',$contact],
 ['','Mobile',$v['mobile']??''],
 ['','Email',$v['email']??''],
 ['','Address',$place],
 ['','Service Area',$areas],
]));

echo card('Tax and Bank Details',rowsHtml([
 ['','PAN',$v['pan']??''],
 ['','GST',$gst],
 ['','Aadhaar',$v['aadhaar']??''],
 ['','Bank (Name / Account / IFSC)',$bankLine],
]));

noteBlock($data,'Note from Operations');
attachmentsCard($data,'KYC Documents');

noteBar('Reply to this email with the Vendor ID (5 digits or more), for example "Vendor ID: 12345". Keep the Request ID in the subject.');
pageEnd('Regards,','Operations Team',$config);
