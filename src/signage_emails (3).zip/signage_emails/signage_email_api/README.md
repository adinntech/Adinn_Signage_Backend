# Adinn Signage Mail API (Code Creation Requests)

PHP API on cPanel that renders the branded HTML mail and sends it. Three mail types:

| `mailtype` | Mail | Required fields |
|---|---|---|
| `combined` | Client Code & Project Code Request | `requestId`, `toEmail`, `client.clientName`, `project.projectName` |
| `client` | New Client Code Creation Request | `requestId`, `toEmail`, `client.clientName` |
| `project` | New Project Code Creation Request | `requestId`, `toEmail`, `client.clientName`, `project.projectName` (`client.clientCode` is shown when sent) |

## Deploy

Upload this folder to `public_html/adinndigital/api/signage_emails/signage_email_api/` (folder names are case-sensitive).

Files: `index_signage.php`, `config.php`, `config.local.php`, `PHPMailer/`, `templates/`. PHPMailer is bundled in `PHPMailer/`; if a Composer `vendor/` folder exists it is used instead. PHP 8.1+.

**Config.** cPanel cannot set env variables, so secrets go in `config.local.php` (copy `config.local.example.php`; never commit it):

- `SIGNAGE_API_KEY` - required. Generate: `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`
- SMTP defaults to the local relay (`localhost:25`, no auth, from `noreply@adinndigital.com`), same as the Roadshow mailer. Optional overrides: `SIGNAGE_SMTP_HOST`, `SIGNAGE_SMTP_PORT`, `SIGNAGE_SMTP_SECURE` (`ssl`/`tls`), `SIGNAGE_SMTP_USER`, `SIGNAGE_SMTP_PASSWORD`, `SIGNAGE_FROM_EMAIL`.

**Backend (Node)** `.env`: `SIGNAGE_MAIL_URL` (the endpoint below) and `SIGNAGE_MAIL_KEY` (same value as `SIGNAGE_API_KEY`). Mailer: `src/modules/codeRequests/signageCodeMail.ts`.

When the key is rotated, update `config.local.php` on the server, `.env.development`, `.env.production`, the live server's env, and Bruno, then restart the Node backend.

Call the API only from the backend or a test client, never from browser or mobile code (the key must stay secret). Use HTTPS.

## Design

Plain, table-based mail with system fonts, normal font weight, one accent colour and no icons or banner images (only the Adinn logo). All shared blocks are in `templates/_common.php`; the header/footer images and `icons/` folder are no longer used. Logo: `https://adinnroadshows.com/images/logo/AdinnLogo.png`.

## Request

```
POST https://adinndigital.com/api/signage_emails/signage_email_api/index_signage.php
Content-Type: application/json
X-API-Key: <SIGNAGE_API_KEY>
```

In Bruno: Headers tab -> `Content-Type` and `X-API-Key` (the header name is `X-API-Key`, not `SIGNAGE_MAIL_KEY`). Body tab -> JSON.

Common fields: `mailtype`, `toEmail` (array or comma-separated), `ccEmail`, `bccEmail`, `subject` (optional, max 200 chars, no line breaks), `requestId` (max 100 chars), `requestDate`, `source`, `message`, `replyTo`, `attachments`.

`bodyHtml` (code requests and vendor): rich text typed on the CRM screen, cleaned to simple tags and shown as "Additional Notes"; `message` (plain text) is the fallback. `requestId` is `Adn-Signage-<ProCode|CliCode|CliProCode|VenReg|VenRate>-ddmmyy<serial>`, for example `Adn-Signage-VenReg-13112601` (the serial keeps counting across years: ...2601 then ...2702). Older IDs such as `ADN-Signage-vnd-06122601` are still recognised in replies.

### 1. Combined (`mailtype: "combined"`)

```json
{
  "mailtype": "combined",
  "toEmail": ["reactdeveloper@adinn.co.in"],
  "ccEmail": ["smm@adinn.co.in", "2002karthikatg@gmail.com"],
  "subject": "Client & Project Code Request - REQ-2026-0105",
  "requestId": "REQ-2026-0105",
  "requestDate": "30 Oct 2026",
  "source": "Client Servicing Team",
  "message": "Please create both codes and confirm.",
  "client": {
    "clientName": "UltraTech Cement Limited",
    "contactPerson": "Jeeva Dhanalakshmi M",
    "email": "clientservice1@adinn.co.in",
    "phone": "9789056789",
    "gstNumber": "33AAACU5678G1Z2",
    "panNumber": "AAACU5678G",
    "address": "123, Industrial Estate, Guindy, Chennai - 600032"
  },
  "project": {
    "projectName": "CEO Meeting Standee",
    "projectType": "Signage",
    "location": "Chennai",
    "startDate": "22 Aug 2026",
    "endDate": "26 Aug 2026",
    "businessUnit": "Signage Solutions",
    "remarks": "Standee required for CEO meeting"
  },
  "attachments": []
}
```

### 2. Client code only (`mailtype: "client"`)

```json
{
  "mailtype": "client",
  "toEmail": ["reactdeveloper@adinn.co.in"],
  "ccEmail": ["smm@adinn.co.in"],
  "subject": "New Client Code Request - REQ-2026-0106",
  "requestId": "REQ-2026-0106",
  "requestDate": "30 Oct 2026",
  "source": "Client Servicing Team",
  "message": "Please create a new client code and notify Client Servicing once done.",
  "client": {
    "clientName": "UltraTech Cement Limited",
    "contactPerson": "Jeeva Dhanalakshmi M",
    "email": "clientservice1@adinn.co.in",
    "phone": "9789056789",
    "gstNumber": "33AAACU5678G1Z2",
    "panNumber": "AAACU5678G",
    "address": "123, Industrial Estate, Guindy, Chennai - 600032"
  },
  "attachments": []
}
```

### 3. Project code only (`mailtype: "project"`)

`client.clientCode` is optional but should be sent when the client already has a code (shown as "(Existing)"). `description` is shown in this mail.

```json
{
  "mailtype": "project",
  "toEmail": ["reactdeveloper@adinn.co.in"],
  "ccEmail": ["smm@adinn.co.in"],
  "subject": "New Project Code Request - PCR-2026-0105",
  "requestId": "PCR-2026-0105",
  "requestDate": "30 Oct 2026",
  "source": "Client Servicing Team",
  "message": "Please create the project code for the order below.",
  "client": {
    "clientName": "GM Modular Pvt Ltd",
    "clientCode": "CLI-0018"
  },
  "project": {
    "projectName": "Recce Tirunelveli Lot 2",
    "projectType": "Signage Recce",
    "location": "Tirunelveli",
    "startDate": "25 Oct 2026",
    "endDate": "27 Oct 2026",
    "businessUnit": "Signage Solutions",
    "description": "Site recce for outdoor signage locations and measurement collection.",
    "remarks": "Confirmed project code is used in Create Project and Recce assignment."
  },
  "attachments": []
}
```

### Attachments (optional, any type)

A filename alone does not attach anything; `base64` must hold the real file bytes (a `data:...;base64,` prefix is accepted).

```json
"attachments": [
  { "filename": "GST_Certificate.pdf", "base64": "JVBERi0xLjQK..." }
]
```

Limits: max 8 files, 8 MB each, request max 18 MB. Allowed: PDF, XLS, XLSX, DOCX, PNG, JPG, ZIP. File contents are checked against the extension.

## Responses

| HTTP | Body | Meaning |
|---|---|---|
| 200 | `{"status":"success","message":"Email accepted by SMTP server", ...}` | Accepted by SMTP (not a delivery guarantee) |
| 401 | `Unauthorized` | `X-API-Key` header missing or wrong |
| 405 | `POST required` | Not a POST |
| 413 | `Request too large` | Over 18 MB |
| 422 | validation message (e.g. `client.clientName required`, `Invalid mailtype`, `Invalid email address`) | Fix the payload |
| 500 | `Email sending failed. Check server logs.` | SMTP error; see `error_log` in the folder |
| 503 | `Server API key is not configured` | `config.local.php` missing or has no key |

## Preview templates without sending

Static samples (no PHP needed): open `preview/vendor-registration.html`, `vendor-rate-approval.html`, `project-code.html`, `project-code-existing.html`, `client-code.html`, `client-project-code.html`, `forgot.html` in a browser. Regenerate after a design change with `node src/signage_emails/signage_email_api/preview/build-previews.mjs` (a JS mirror of `_common.php`; keep both in step).


Use a private server-side PHP script with `ob_start()` and `include` with sample `$data` and `$config`. Never expose a public unauthenticated mail preview endpoint.

### 4. Vendor registration request (`mailtype: "vendor"`)

Sent by the CRM when Operations mails Accounts to create a new vendor (Vendor > Registration > Registration mail). `requestId` is the vendor code (VND-0008). `bodyHtml` is the text written on the CRM mail screen; the API keeps only simple formatting tags (`p br strong b em i u ul ol li h3 h4 div span`) and drops every attribute, script and link. `attachments[].label` (optional) is the document name shown on the attachment card (PAN card, Bank proof...). Limits are the same as the other mails: 8 files, 8 MB each, PDF / PNG / JPG / WEBP etc.

```json
{
  "mailtype": "vendor",
  "toEmail": ["accounts@adinn.co.in"],
  "ccEmail": ["ops@adinn.co.in"],
  "subject": "Vendor registration request: Sri Murugan Signs (VND-0008)",
  "requestId": "VND-0008",
  "requestDate": "03 Nov 2026",
  "source": "Operations Team",
  "replyTo": "ops@adinn.co.in",
  "vendor": { "vendorName": "Sri Murugan Signs", "vendorType": "One-man / Freelancer", "vendorCode": "VND-0008" },
  "bodyHtml": "<p>Hi Team,</p><p>Please register the vendor and reply with the <strong>Vendor ID</strong>.</p>",
  "attachments": [{ "filename": "pan.pdf", "base64": "...", "label": "PAN card" }]
}
```

Template: `templates/signage_vendor_registration_request.php`. Node client: `src/modules/vendors/signageVendorMail.ts`.

### 5. Vendor amount approval request (`mailtype: "rateapproval"`)

Sent by the CRM when a vendor cost is typed above the company rate (Admin > Cost Rates). `requestId` is `Adn-Signage-VenRate-ddmmyy<serial>`; the approver replies APPROVED or NOT APPROVED and the CRM reads the reply from the reply mailbox. Template: `templates/signage_vendor_rate_approval.php`. Payload: `vendor { vendorName, vendorNo }`, `amounts { requestedRate, requestedFar, limitRate, limitFar, currentRate, currentFar, requestedBy }` (already formatted, for example "₹500"), `replyTo`. No attachments. Upload `index_signage.php` and the new template together.
