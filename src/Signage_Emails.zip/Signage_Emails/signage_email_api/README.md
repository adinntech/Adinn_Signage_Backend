# Adinn Signage Mail API

Deploy the directory as `/public_html/api/signage/` and install PHPMailer via `composer require phpmailer/phpmailer` in that directory. PHP 8.1+ recommended.

Configure server environment variables (not browser JavaScript):

- `SIGNAGE_API_KEY` - required, long random secret
- `SIGNAGE_SMTP_HOST` - default localhost
- `SIGNAGE_SMTP_PORT` - default 25
- `SIGNAGE_SMTP_USER`, `SIGNAGE_SMTP_PASSWORD` - optional if local SMTP relay
- `SIGNAGE_SMTP_SECURE` - `tls` for port 587, `ssl` for port 465, blank for trusted local relay
- `SIGNAGE_FROM_EMAIL` - defaults to noreply@adinndigital.com

The API must be called only from your authenticated backend, **not directly from browser JavaScript**. Keep the API key out of the frontend. Use HTTPS, rate limiting, audit logs and recipient allowlisting for production.

## Example request

```bash
curl -X POST 'https://adinndigital.com/api/signage/index_signage.php' \
 -H 'Content-Type: application/json' -H 'X-API-Key: YOUR_SERVER_API_KEY' \
 --data-binary @request.json
```

## Example JSON

```json
{
  "mailtype": "combined",
  "toEmail": ["approvals@example.com"],
  "ccEmail": ["manager@example.com"],
  "subject": "Client & Project Code Request - REQ-2026-0105",
  "requestId": "REQ-2026-0105",
  "requestDate": "30 Oct 2026",
  "source": "Client Servicing Team",
  "message": "Please review the request and confirm the codes.",
  "client": {
    "clientName": "UltraTech Cement Limited",
    "contactPerson": "Jeeva Dhanalakshmi M",
    "email": "clientservice1@adinn.co.in",
    "phone": "9789056789",
    "gstNumber": "33AAACU5678G1Z2",
    "panNumber": "AAACU5678G",
    "address": "123, Industrial Estate, Guindy, Chennai - 600032"
  },
  "project": {
    "projectName": "CEO Meeting Standee",
    "projectType": "Signage",
    "location": "Chennai",
    "startDate": "22 Aug 2026",
    "endDate": "26 Aug 2026",
    "businessUnit": "Signage Solutions",
    "remarks": "Standee required for CEO meeting"
  },
  "attachments": [{"filename":"Client_Onboarding_Form.pdf","base64":"BASE64_ENCODED_PDF_CONTENT"}]
}
```

For client-only: set `mailtype=client`, provide `client`, omit `project`. For project-only: set `mailtype=project`, provide `client.clientCode` and `project`. Attachments are optional, but must contain actual Base64 file bytes; a filename alone does not attach the document. Maximum 8 attachments, each 8 MiB, request max 18 MiB. Allowed PDF, XLS/XLSX, DOCX, PNG, JPG, ZIP. The API reports SMTP acceptance, not guaranteed inbox delivery.

To preview templates without sending, make a private server-side PHP preview script using `ob_start()` and `include` with sample `$data` and `$config`; never expose a public unauthenticated mail preview endpoint.
